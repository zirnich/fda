<!DOCTYPE html>
<html>
<body>
  <title>Tampil Data PHP & MYSQL</title>
  <table border="1" widht="100%" align="center">
    <caption>Tampil Data Bengkel</caption>
    <thead>
      <tr>
        <th>id Bengkel</th>
        <th>Nama Bengkel</th>
        <th>Nama Pemilik</th>
        <th>Nama Pimpinan</th>
        <th>Alamat Bengkel</th>
        <th>Aksi</th>
    </tr>
  </thead>
  <tbody>
    <?php
    include("koneksi.php");
    $tampil=$koneksi->query("SELECT IDBengkel, NamaBengkel, NamaPemilik, NamaPimpinan ,Alamat FROM bengkel");
    $cekdata=$tampil->num_rows;
    if ($cekdata > 0) {
      while ($data=$tampil->fetch_object()) {
      ?>

        <tr>
        <td><?php echo $data->IDBengkel ?></td>;
        <td><?php echo $data->NamaBengkel ?></td>;
        <td><?php echo $data->NamaPemilik ?></td>;
        <td><?php echo $data->NamaPimpinan ?></td>;
        <td><?php echo $data->Alamat ?></td>;
        <td colspan="2">
        <a href="Rubah.php?id=<?php echo $data->IDBengkel; ?>">RUBAH ||</a>
        <a href="Hapus.php?id=<?php echo $data->IDBengkel; ?>">|| HAPUS</a>
        </td>
      </tr>
  <?php
      }
    }else{
      ?>
    <tr>
      <td colspan="4">Maaf Data Kosong !</td>
      <?php
    }
     ?>
   </tbody>
 </table>
</body>
</html>
