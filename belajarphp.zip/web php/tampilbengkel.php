<!DOCTYPE html>
<html>
<body>
  <title>Tampil Data PHP & MYSQL</title>
  <table border="1" widht="100%" align="center">
    <caption>Tampil Data Bengkel</caption>
    <thead>
      <tr>
        <th>id Bengkel</th>
        <th>Nama Bengkel</th>
        <th>Nama Pemilik</th>
        <th>Nama Pimpinan</th>
        <th>Alamat</th>
        <th>Nama Kelurahan</th>
    </tr>
  </thead>
  <tbody>
    <?php
    include("koneksi.php");
    $tampil=$koneksi->query("SELECT bengkel.IDBengkel, bengkel.NamaBengkel, bengkel.NamaPemilik, bengkel.NamaPimpinan, bengkel.Alamat,
      referensikelurahan.NamaKelurahan FROM bengkel INNER JOIN referensikelurahan ON bengkel.IDReferensiKelurahan = referensikelurahan.IDReferensiKelurahan");
    $cekdata=$tampil->num_rows;
    if ($cekdata > 0) {
      while ($data=$tampil->fetch_object()) {
      ?>

        <tr>
        <td><?php echo $data->IDBengkel ?></td>;
        <td><?php echo $data->NamaBengkel ?></td>;
        <td><?php echo $data->NamaPemilik ?></td>;
        <td><?php echo $data->NamaPimpinan ?></td>;
        <td><?php echo $data->Alamat ?></td>;
        <td><?php echo $data->NamaKelurahan ?></td>;
        </td>
      </tr>
  <?php
      }
    }else{
      ?>
    <tr>
      <td colspan="4">Maaf Data Kosong !</td>
      <?php
    }
     ?>
   </tbody>
 </table>
</body>
</html>
