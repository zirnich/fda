<!DOCTYPE html>
<html>
<head>
    <title>Tampil data PHP & MYSQL</title>
</head>
<body>
    <table border="1" width="100%" align="center">
    <caption>Tampil Data Bengkel</caption>
    <thead>
        <tr>
            <th>Id Bengkel</th>
            <th>Nama Bengkel</th>
            <th>Nama Pemilik</th>
            <th>Nama Kelurahan</th>

        
        </tr>
    </thead>
         <?php
          include('koneksi.php');
          $tampil = $koneksi->query("SELECT * FROM bengkel INNER JOIN referensikelurahan ON bengkel.IDReferensiKelurahan=referensikelurahan.IDReferensiKelurahan ");
          $cekData = $tampil->num_rows;
          if($cekData > 0) {
            while ($data = $tampil->fetch_object()) {
          
         ?>
         <tr>
            <td><?php echo $data->IDBengkel ?></td>
            <td><?php echo $data->NamaBengkel ?></td>
            <td><?php echo $data->NamaPemilik ?></td>
            <td><?php echo $data->NamaKelurahan ?></td>

         </tr>
         <?php
             }
         }else{
            ?>
            <tr>
                <td colspan="4">Maaf Data Kosong !</td>
            </tr>
            <?php
         }
        ?>
    </table>
</body>
</html>