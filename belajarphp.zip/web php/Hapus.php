<?php
  include ('koneksi.php');
  if (isset($_GET['id'])) {
    $IDBengkel = $_GET['id'];
    $hapusdata = $koneksi->query("DELETE FROM bengkel WHERE IDBengkel = '".$IDBengkel."'");

    if ($hapusdata){
      echo "<script>alert('Data Bengkel Berhasil Di Hapus !');
      window.location.href='tampilfiledata.php';</script>";
    }
  }else {
    echo "<script>alert('Anda Belum Memilih Data !');history.go(-1);</script>";
  }
 ?>
