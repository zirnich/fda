<?php
  include ('koneksi.php');
  if (isset($_GET['id'])) {
    $IDBengkel = $_GET['id'];
    $query = $koneksi->query("SELECT * FROM bengkel WHERE IDBengkel = '".$IDBengkel."'");
    $data = $query->fetch_object();
  }else {
    echo "<script>alert('Anda Belum Memilih Data !');history.go(-1);</script>";
  }
 ?>

 <form action="" method="POST">
     <table align="center" border="0">
       <tbody>
         <tr>
           <td>ID Bengkel</td>
           <td><input type="text" value="<?php echo $data->IDBengkel ?>" name="IDBengkel" value="" placeholder="Masukan ID Bengkel" readonly required>
           </td>
           <tr>
             <td>Nama Bengkel</td>
             <td><input type="text" name="NamaBengkel"  value="<?php echo $data->NamaBengkel ?>" placeholder="Masukan Nama Bengkel" required>
             </td>
           </tr>
           <tr>
             <td>Nama Pemilik</td>
             <td><input type="text" name="NamaPemilik"  value="<?php echo $data->NamaPemilik ?>" placeholder="Masukan Nama Pemilik" required>
             </td>
           </tr>
           <tr>
             <td>Nama Pimpinan</td>
             <td><input type="text" name="NamaPimpinan"  value="<?php echo $data->NamaPimpinan ?>" placeholder="Masukan Nama Pimpinan" required>
             </td>
           </tr>
           <tr>
             <td>Alamat Bengkel</td>
             <td>
               <textarea name="AlamatBengkel" placeholder="Masukan Alamat Bengkel" required><?php echo $data->Alamat ?></textarea>
             </td>
           </tr>
           <tr>
           <td colspan="2" align='center'>
             <a href="tampilfiledata.php"><input type="button" name="batal" value="Batal"></a>
             <input type="submit" name="rubah" value="Rubah">
           </td>
         </tr>
       </tbody>
      </table>
    </form>

<?php
if (isset($_POST['rubah'])) {

  $IDBengkel = $_POST['IDBengkel'];
  $NamaBengkel = $_POST['NamaBengkel'];
  $NamaPemilik = $_POST['NamaPemilik'];
  $NamaPimpinan = $_POST['NamaPimpinan'];
  $Alamat = $_POST['AlamatBengkel'];

  $rubahdata = $koneksi->query("UPDATE bengkel SET NamaBengkel = '".$NamaBengkel."',NamaPemilik = '".$NamaPemilik."',NamaPimpinan = '".$NamaPimpinan."',
    Alamat = '".$Alamat."' WHERE IDBengkel = '".$_GET['id']."'");

    if ($rubahdata) {
      echo "<script>
            alert('Data Bengkel Berhasil Di Rubah !');
            window.location.href='tampilfiledata.php';</script>";
    }else {
      echo "<script>alert('Data Bengkel Gagal Di Rubah !');</script>";
    }
  }
 ?>
